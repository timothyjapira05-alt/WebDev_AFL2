<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <div class="navbar-nav">
            <a class="nav-link" href="<?php echo e(url('/')); ?>">Home</a>
            <a class="nav-link" href="<?php echo e(url('/about us')); ?>">about us</a>
            <a class="nav-link" href="<?php echo e(url('/Story')); ?>">Our Story</a>
            <a class="nav-link" href="<?php echo e(url('/Blog')); ?>">Blog</a>
            <a class="nav-link" href="<?php echo e(url('/GetInTouch')); ?>">Get in Touch</a>
        </div>
    </div>
</nav><?php /**PATH C:\Users\timot\OneDrive\WebDev-Laravel\WebDev_Kelompok AFL\WebDev_AFL2\resources\views/template/Navbar.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e(ucfirst(Route::currentRouteName())); ?> — Naturae</title>
    <link rel="stylesheet" href="<?php echo e(asset('mydesign/mystyle.css')); ?>">
</head>
<body>
    <?php echo $__env->make('Template.Navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>
</html>
<?php /**PATH C:\Users\timot\OneDrive\WebDev-Laravel\WebDev_Kelompok AFL\WebDev_AFL2\resources\views/pages/blank.blade.php ENDPATH**/ ?>
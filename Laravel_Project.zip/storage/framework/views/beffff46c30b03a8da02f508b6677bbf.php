<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($title); ?> — Naturae</title>
    <link rel="stylesheet" href="<?php echo e(asset('mydesign/mystyle.css')); ?>">
</head>
<body>
    <?php echo $__env->make('Template.Navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="placeholder-page">
        <p class="eyebrow"><span class="eyebrow-mark" aria-hidden="true"></span> A little more nature</p>
        <h1><?php echo e($title); ?></h1>
        <p>This corner of Naturae is still taking root. We can’t wait to share it with you.</p>
        <a class="button button-dark" href="<?php echo e(route('home')); ?>">Back to home <span aria-hidden="true">↗</span></a>
    </main>
</body>
</html>
<?php /**PATH C:\Users\timot\OneDrive\WebDev-Laravel\WebDev_Kelompok AFL\WebDev_AFL2\resources\views/pages/placeholder.blade.php ENDPATH**/ ?>
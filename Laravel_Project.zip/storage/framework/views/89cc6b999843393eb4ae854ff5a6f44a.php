<nav class="main-nav">
    <a href="<?php echo e(url('/')); ?>">Home</a>
    <a href="<?php echo e(url('/project')); ?>">My Projects</a>
    <a href="<?php echo e(url('/contact')); ?>">Contact</a>
    <a href="<?php echo e(url('/Student')); ?>">Students</a>
</nav><?php /**PATH C:\Users\timot\OneDrive\WebDev-Laravel\WebDev_Kelompok AFL\WebDev_AFL2\resources\views/template/navbar.blade.php ENDPATH**/ ?>